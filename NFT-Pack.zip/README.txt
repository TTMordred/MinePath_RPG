# Custom Items Resource Pack

This resource pack changes the texture of special items based on the metadata files in D:\Code\Pack\metadata.

## Requirements
- Minecraft 1.18.2
- OptiFine HD U H8 (or newer)

## Installation
1. Install OptiFine for Minecraft 1.18.2
2. Place this resource pack folder in your `.minecraft/resourcepacks` directory
3. Start Minecraft and enable the resource pack in the options menu

## How to Use
This resource pack supports the following custom items:

### Laser Pickaxe
1. Laser Pickaxe I - Iron Pickaxe with CustomModelData 7501
2. Laser Pickaxe II - Iron Pickaxe with CustomModelData 7502
3. Laser Pickaxe III - Diamond Pickaxe with CustomModelData 7503
4. Laser Pickaxe IV - Diamond Pickaxe with CustomModelData 7504
5. Laser Pickaxe V - Netherite Pickaxe with CustomModelData 7505

### Explosion Pickaxe
1. Explosion Pickaxe I - Iron Pickaxe with CustomModelData 7401
2. Explosion Pickaxe II - Iron Pickaxe with CustomModelData 7402
3. Explosion Pickaxe III - Diamond Pickaxe with CustomModelData 7403
4. Explosion Pickaxe IV - Diamond Pickaxe with CustomModelData 7404
5. Explosion Pickaxe V - Netherite Pickaxe with CustomModelData 7405

### Lucky Charm
1. Lucky Charm I - Emerald with CustomModelData 8001
2. Lucky Charm II - Emerald with CustomModelData 8002
3. Lucky Charm V - Emerald with CustomModelData 8005
4. Lucky Charm X - Emerald with CustomModelData 8010
5. Lucky Charm XX - Emerald with CustomModelData 8020

Each item will have its own unique texture.

## Notes
- This resource pack requires OptiFine to work properly
- The texture change is based on CustomModelData values
- Works with the metadata files in D:\Code\Pack\metadata
- The resource pack will work with any item name as long as the CustomModelData matches
